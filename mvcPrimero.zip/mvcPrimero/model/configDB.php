<?php
    define('CADENA_CONEXION','mysql:dbname=libreria; host=localhost');
    define('USUARIO_BDD', 'root');
    define('CONTRA_BDD','');

?>
